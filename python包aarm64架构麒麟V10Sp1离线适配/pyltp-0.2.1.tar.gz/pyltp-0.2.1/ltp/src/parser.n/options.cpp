#include "parser.n/options.h"

namespace ltp {
namespace depparser {

std::string SpecialOption::UNKNOWN = "$unk";
std::string SpecialOption::NIL = "$nil";
std::string SpecialOption::ROOT = "$root";

} //  namespace depparser
} //  namespace ltp
