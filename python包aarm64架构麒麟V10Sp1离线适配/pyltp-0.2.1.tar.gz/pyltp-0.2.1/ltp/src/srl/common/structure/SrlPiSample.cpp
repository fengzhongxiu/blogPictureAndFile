//
// Created by liu on 2017/5/18.
//

#include "SrlPiSample.h"
#include "Const.h"

Word SrlPiSample::root = Word(0, ROOT_MARK, ROOT_MARK, -1, ROOT_MARK, "before", NIL_LABEL);

