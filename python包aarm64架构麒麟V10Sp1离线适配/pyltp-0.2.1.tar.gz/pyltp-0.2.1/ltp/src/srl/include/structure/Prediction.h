//
// Created by liu on 2017/1/6.
//

#ifndef PROJECT_PREDICTION_H
#define PROJECT_PREDICTION_H

#include "utility"
using namespace std;

typedef vector<pair<unsigned, double>> Prediction;

#endif //PROJECT_PREDICTION_H
